# AUREN AUTOMATION website

Static responsive B2B industrial automation website generated from the supplied AUREN master brief.

## Included
- Responsive homepage and navigation
- Product catalogue + six category pages
- Solutions page
- Industries page
- About, Resources, Contact and RFQ pages
- Legal placeholder pages
- WhatsApp CTA using the supplied business WhatsApp number
- Email CTA using sales@aurenautomation.in
- SEO metadata, robots.txt and sitemap.xml
- Mobile sticky Request Quote CTA
- RFQ form UI with client-side confirmation
- No fabricated certifications, customer logos, technical specifications or performance claims

## Before production launch
1. Replace the text-only AUREN logo mark with the final supplied logo asset.
2. Connect the RFQ form to a secure backend/email/CRM.
3. Add verified product brands, models, specifications and datasheets.
4. Add real company address, phone, GST/CIN/IEC and legal policies where applicable.
5. Add real LinkedIn/Instagram/YouTube URLs.
6. Add optimized real industrial photography.
7. Deploy behind HTTPS and configure server-side spam protection.
